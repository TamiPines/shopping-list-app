import { Routes, Route } from 'react-router-dom';
import App from './App';
import Summary from './pages/Summary';

export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/summary" element={<Summary />} />
    </Routes>
  );
}