import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CategorySelect from './features/categories/categorySelect';
import ProductInput from './features/products/productInput';
import CartView from './features/cart/cartView';
import { useAppDispatch } from './app/hooks';
import { addToCart } from './features/cart/cartSlice';

function App() {
  const [category, setCategory] = useState('');
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleAdd = (name: string, qty: number) => {
    if (!category || !name) return;
    dispatch(addToCart({ category, name, qty }));
  };

  return (
    <div dir="rtl" style={{ textAlign: 'center', margin: 40 }}>
      <h1>מסך ראשון — רשימת קניות</h1>
      <CategorySelect value={category} onChange={setCategory} />
      <ProductInput onAdd={handleAdd} />
      <CartView />
      <button style={{ marginTop: 40 }} onClick={() => navigate('/summary')}>
        המשך להזמנה
      </button>
    </div>
  );
}

export default App;