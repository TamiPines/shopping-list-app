import React, { useState } from 'react';
import { useAppSelector, useAppDispatch } from '../app/hooks';
import { useNavigate } from 'react-router-dom';

type OrderForm = {
  fullName: string;
  address: string;
  email: string;
};

export default function Summary() {
  const cart = useAppSelector(state => state.cart.items);
  const [form, setForm] = useState<OrderForm>({ fullName: '', address: '', email: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.address || !form.email) {
      setError('יש למלא את כל השדות');
      return;
    }
    setError('');
    // שליחת ההזמנה לשרת
    const response = await fetch('http://localhost:4000/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, cart }),
    });
    if (response.ok) {
      alert('ההזמנה התקבלה בהצלחה!');
      navigate('/');
    } else {
      setError('אירעה שגיאה בשליחת ההזמנה');
    }
  };

  return (
    <div style={{ maxWidth: 500, margin: '40px auto', direction: 'rtl' }}>
      <h2>סיכום הזמנה</h2>
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <input
          name="fullName"
          placeholder="שם פרטי ומשפחה"
          value={form.fullName}
          onChange={handleChange}
          required
        />
        <input
          name="address"
          placeholder="כתובת מלאה"
          value={form.address}
          onChange={handleChange}
          required
        />
        <input
          name="email"
          placeholder="מייל"
          type="email"
          value={form.email}
          onChange={handleChange}
          required
        />
        <h4>מוצרים בהזמנה:</h4>
        {Object.entries(cart).length === 0 ? (
          <div>העגלה ריקה</div>
        ) : (
          <ul style={{ textAlign: 'right' }}>
            {Object.entries(cart).map(([cat, items]) =>
              items.map((item, idx) => (
                <li key={cat + idx}>
                  {item.name} ({cat}) - {item.qty}
                </li>
              ))
            )}
          </ul>
        )}
        {error && <div style={{ color: 'red' }}>{error}</div>}
        <button type="submit">אשר הזמנה</button>
      </form>
    </div>
  );
}