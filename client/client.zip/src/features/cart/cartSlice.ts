import { createSlice } from '@reduxjs/toolkit';

interface CartItem {
  name: string;
  qty: number;
}

interface CartState {
  items: {
    [category: string]: CartItem[];
  };
}

const initialState: CartState = {
  items: {},
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart: (state, action) => {
      const { category, name, qty } = action.payload;
      if (!state.items[category]) state.items[category] = [];
      // אם המוצר כבר קיים בקטגוריה, נעדכן את הכמות
      const existing = state.items[category].find(item => item.name === name);
      if (existing) {
        existing.qty += qty;
      } else {
        state.items[category].push({ name, qty });
      }
    }
  }
});

export const { addToCart } = cartSlice.actions;
export default cartSlice.reducer;