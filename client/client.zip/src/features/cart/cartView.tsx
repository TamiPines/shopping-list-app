import { useAppSelector } from '../../app/hooks';

// Define the type for a cart item
type CartItem = {
  name: string;
  qty: number;
};

// Define the type for the cart object
type Cart = {
  [category: string]: CartItem[];
};

export default function CartView() {
  // שים לב: יש לבחור את הסל מה-state הנכון
  const cart = useAppSelector(state => state.cart.items) as Cart;

  if (Object.keys(cart).length === 0) {
    return <div>העגלה ריקה</div>;
  }

  return (
    <div style={{ display: 'flex', gap: '32px', justifyContent: 'center', marginTop: 32 }}>
      {Object.entries(cart).map(([cat, items]) => (
        <div key={cat}>
          <h3
            style={{
              padding: '8px 0',
              marginBottom: 12,
              textAlign: 'center'
            }}
          >
            {cat}
          </h3>
          <ul style={{ listStyle: 'none', padding: 0, textAlign: 'right' }}>
            {items.map((item, idx) => (
              <li key={idx} style={{ marginBottom: 6 }}>
                {item.name} – {item.qty}
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}