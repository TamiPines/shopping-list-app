import { useEffect } from 'react';
import { useAppDispatch, useAppSelector } from '../../app/hooks';
import { fetchCategories } from './categorySlice';

// שים לב: שם קומפוננטה ב-React צריך להתחיל באות גדולה
export default function CategorySelect({ value, onChange }: { value: string; onChange: (val: string) => void }) {
    const dispatch = useAppDispatch();
    const categories = useAppSelector(state => state.categories.list);

    useEffect(() => {
        dispatch(fetchCategories());
    }, [dispatch]);

    return (
        <select value={value} onChange={e => onChange(e.target.value)}>
            <option value="">בחר קטגוריה</option>
            {categories.map((cat: string, idx: number) => (
                <option key={idx} value={cat}>{cat}</option>
            ))}
        </select>
    );
}