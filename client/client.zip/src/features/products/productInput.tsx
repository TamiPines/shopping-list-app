import { useState } from 'react';

export default function ProductInput({ onAdd }: { onAdd: (name: string, qty: number) => void }) {
  const [name, setName] = useState('');
  const [qty, setQty] = useState(1);

  return (
    <div>
      <input
        placeholder="שם המוצר"
        value={name}
        onChange={e => setName(e.target.value)}
      />
      <input
        type="number"
        min="1"
        value={qty}
        onChange={e => setQty(Number(e.target.value))}
        style={{ width: 60, marginRight: 8 }}
      />
      <button onClick={() => { onAdd(name, qty); setName(''); setQty(1); }}>
        הוסף מוצר לסל
      </button>
    </div>
  );
}